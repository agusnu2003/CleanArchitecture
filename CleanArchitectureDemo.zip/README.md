# CleanArchitectureDemo

Ejemplo académico de Clean Architecture en C#

## Estructura

```text
src/
  CleanArchitectureDemo.Domain/          # Entidades y reglas de negocio
  CleanArchitectureDemo.Application/    # Casos de uso y puertos
  CleanArchitectureDemo.Infrastructure/ # Adaptadores concretos
  CleanArchitectureDemo.Api/            # Entrada HTTP y composición de dependencias
tests/
  CleanArchitectureDemo.Tests/          # Pruebas de dominio y aplicación
```

La dirección de las dependencias apunta hacia el dominio:

```text
API -> Infrastructure -> Application -> Domain
```

La aplicación depende de `ITaskRepository`, una abstracción. Por eso una base de datos real podría reemplazar al repositorio en memoria sin modificar los casos de uso.

## Ejecutar

```powershell
dotnet test
dotnet run --project src/CleanArchitectureDemo.Api
```

En entorno de desarrollo, Swagger UI queda disponible en `http://localhost:5000/swagger` (el puerto puede variar según `launchSettings.json`).

Luego se pueden probar `GET /tasks` y `POST /tasks` con un cuerpo como:

```json
{ "title": "Repasar inversión de dependencias" }
```