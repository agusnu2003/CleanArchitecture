using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Application.Tasks;
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Tests;

public sealed class TaskTests
{
    [Fact]
    public void Create_rejects_an_empty_title()
    {
        var action = () => TaskItem.Create(" ");

        Assert.Throws<ArgumentException>(action);
    }

    [Fact]
    public async Task Create_use_case_persists_and_returns_a_dto()
    {
        var repository = new FakeTaskRepository();
        var useCase = new CreateTaskUseCase(repository);

        var result = await useCase.ExecuteAsync("  Estudiar Clean Architecture  ");

        Assert.Equal("Estudiar Clean Architecture", result.Title);
        Assert.Single(repository.Tasks);
    }

    private sealed class FakeTaskRepository : ITaskRepository
    {
        public List<TaskItem> Tasks { get; } = [];

        public Task AddAsync(TaskItem task, CancellationToken cancellationToken = default)
        {
            Tasks.Add(task);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<TaskItem>> GetAllAsync(CancellationToken cancellationToken = default)
        {
            return Task.FromResult<IReadOnlyCollection<TaskItem>>(Tasks);
        }
    }
}