using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Application.Abstractions;

/// <summary>
/// Puerto de salida: la aplicación expresa qué necesita, sin decidir cómo se guarda.
/// </summary>
public interface ITaskRepository
{
    Task AddAsync(TaskItem task, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<TaskItem>> GetAllAsync(CancellationToken cancellationToken = default);
}