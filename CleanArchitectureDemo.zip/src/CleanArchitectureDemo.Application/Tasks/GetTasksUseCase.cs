using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Application.Tasks;

public sealed class GetTasksUseCase(ITaskRepository repository)
{
    public async Task<IReadOnlyCollection<TaskDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        var tasks = await repository.GetAllAsync(cancellationToken);
        return tasks.Select(ToDto).ToArray();
    }

    private static TaskDto ToDto(TaskItem task) =>
        new(task.Id, task.Title, task.IsCompleted, task.CreatedAtUtc);
}