namespace CleanArchitectureDemo.Application.Tasks;

/// <summary>
/// DTO: evita exponer directamente la entidad de dominio hacia la API.
/// </summary>
public sealed record TaskDto(Guid Id, string Title, bool IsCompleted, DateTime CreatedAtUtc);