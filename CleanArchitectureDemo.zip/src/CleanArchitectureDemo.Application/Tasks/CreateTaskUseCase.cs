using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Application.Tasks;

public sealed class CreateTaskUseCase(ITaskRepository repository)
{
    public async Task<TaskDto> ExecuteAsync(string title, CancellationToken cancellationToken = default)
    {
        // La regla de negocio vive en la entidad, no en el controlador.
        var task = TaskItem.Create(title);
        await repository.AddAsync(task, cancellationToken);

        return ToDto(task);
    }

    private static TaskDto ToDto(TaskItem task) =>
        new(task.Id, task.Title, task.IsCompleted, task.CreatedAtUtc);
}