using System.Collections.Concurrent;
using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Infrastructure;

/// <summary>
/// Adaptador de infraestructura. Se perderán los datos al reiniciar la aplicación,
/// lo cual mantiene la demostración enfocada en las dependencias entre capas.
/// </summary>
public sealed class InMemoryTaskRepository : ITaskRepository
{
    private readonly ConcurrentDictionary<Guid, TaskItem> tasks = new();

    public Task AddAsync(TaskItem task, CancellationToken cancellationToken = default)
    {
        tasks[task.Id] = task;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyCollection<TaskItem>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyCollection<TaskItem> result = tasks.Values.OrderBy(task => task.CreatedAtUtc).ToArray();
        return Task.FromResult(result);
    }
}