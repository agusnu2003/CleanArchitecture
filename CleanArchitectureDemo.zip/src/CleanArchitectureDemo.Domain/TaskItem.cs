namespace CleanArchitectureDemo.Domain;

/// <summary>
/// Entidad principal del dominio. No conoce bases de datos, HTTP ni frameworks.
/// </summary>
public sealed class TaskItem
{
    private TaskItem(Guid id, string title, DateTime createdAtUtc)
    {
        Id = id;
        Title = title;
        CreatedAtUtc = createdAtUtc;
    }

    public Guid Id { get; }
    public string Title { get; }
    public DateTime CreatedAtUtc { get; }
    public bool IsCompleted { get; private set; }

    public static TaskItem Create(string title)
    {
        if (string.IsNullOrWhiteSpace(title))
        {
            throw new ArgumentException("El título es obligatorio.", nameof(title));
        }

        return new TaskItem(Guid.NewGuid(), title.Trim(), DateTime.UtcNow);
    }

    public void Complete()
    {
        IsCompleted = true;
    }
}