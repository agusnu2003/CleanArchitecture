using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Application.Tasks;
using CleanArchitectureDemo.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

// La API compone las piezas concretas; las capas internas no dependen de este proyecto.
builder.Services.AddSingleton<ITaskRepository, InMemoryTaskRepository>();
builder.Services.AddScoped<CreateTaskUseCase>();
builder.Services.AddScoped<GetTasksUseCase>();

// Registra el explorador de endpoints y genera el documento OpenAPI para Swagger UI.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Swagger es especialmente útil durante el desarrollo para probar la API desde el navegador.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/tasks", async (GetTasksUseCase useCase, CancellationToken cancellationToken) =>
{
    var tasks = await useCase.ExecuteAsync(cancellationToken);
    return Results.Ok(tasks);
})
.WithName("GetTasks")
.WithOpenApi();

app.MapPost("/tasks", async (
    CreateTaskRequest request,
    CreateTaskUseCase useCase,
    CancellationToken cancellationToken) =>
{
    try
    {
        var task = await useCase.ExecuteAsync(request.Title, cancellationToken);
        return Results.Created($"/tasks/{task.Id}", task);
    }
    catch (ArgumentException exception)
    {
        return Results.BadRequest(new { error = exception.Message });
    }
})
.WithName("CreateTask")
.WithOpenApi();

app.Run();

public sealed record CreateTaskRequest(string Title);
